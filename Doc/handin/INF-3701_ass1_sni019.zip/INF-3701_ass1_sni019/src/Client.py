'''
Created on Jan 23, 2013

@author: Simon
'''
import GameHandler


if __name__ == '__main__':    
    player = GameHandler.Game()
    player.start()
    