To run the code,

int terminal:

python client.py


Server setting can be changed in the properties.py file